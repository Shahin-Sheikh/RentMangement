import java.awt.*;
import java.awt.font.*;
import java.io.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.table.DefaultTableModel;

public class Guest extends User implements ActionListener{
	private JTextField address,flatId,entryTime,exitTime,refName;
	private JButton entryButton,exitButton,cancelButton;	
	private JLabel lName,lPhone,msg,l2,l3,l4,l5,l6;	
	public Guest(){
		super.setTitle("Guest Management");
		/* Start Code of Panel 1 */    
		JPanel panel=new JPanel(new BorderLayout());

		lName=new JLabel("Name: ");
		lName.setFont(font1);
		lName.setBounds(20,60,125,30);
		panel.add(lName);
				
		name=new JTextField(10);
		name.setBounds(125,60,210,30);
		panel.add(name);
			
		l2=new JLabel("Mobile No: ");
		l2.setFont(font1);
		l2.setBounds(20,95,125,30);
		panel.add(l2);
				
		phoneNo=new JTextField(10);
		phoneNo.setBounds(125,95,210,30);
		panel.add(phoneNo);
		
		l3=new JLabel("Address: ");
		l3.setFont(font1);
		l3.setBounds(20,130,125,30);
		panel.add(l3);
				
		address=new JTextField(10);
		address.setBounds(125,130,210,30);
		panel.add(address);
		
		l4=new JLabel("Flat ID: ");
		l4.setFont(font1);
		l4.setBounds(20,165,125,30);
		panel.add(l4);
		
		flatId=new JTextField(10);
		flatId.setBounds(125,165,210,30);
		panel.add(flatId);
		
		l5=new JLabel("Entry Time: ");
		l5.setFont(font1);
		l5.setBounds(20,200,125,30);
		panel.add(l5);
		
		entryTime=new JTextField(10);
		entryTime.setBounds(125,200,210,30);
		entryTime.setText(getNowTime());
		entryTime.setEditable(false);
		panel.add(entryTime);
		
		l6=new JLabel("Ref Name: ");
		l6.setFont(font1);
		l6.setBounds(20,235,125,30);
		panel.add(l6);
		
		refName=new JTextField(10);
		refName.setBounds(125,235,210,30);
		panel.add(refName);
		
		// l7=new JLabel("Ref Name: ");
		// l7.setFont(font1);
		// l7.setBounds(20,270,125,30);
		// panel.add(l7);
		
		// refName=new JTextField(10);
		// refName.setBounds(125,270,210,30);
		// panel.add(refName);

		entryButton=new JButton("  Entry  ");
		entryButton.setBackground(new Color(0x449d44));
		entryButton.setForeground(Color.white);
		entryButton.setBounds(125,305,105,30);
		panel.add(entryButton);
		
		cancelButton=new JButton("  Cancel  ");
		cancelButton.setBackground(new Color(0xc9302c));
		cancelButton.setForeground(Color.white);
		cancelButton.setBounds(225,305,105,30);
		panel.add(cancelButton);
		
		msg=new JLabel("  ");
		msg.setBounds(215,340,210,30);
		panel.add(msg);
		
		panel.setBounds(0,0,500,500);    
		panel.setBackground(new Color(0xe5e4e4));
		this.add(panel); 
		
		/* End Code of Panel 2 */
		this.showInfo();
		/* End Code of Panel 2 */

		/* Start Code of Panel 3 */
		JPanel panel3=new JPanel();
		// JLabel renderLbl=new JLabel("Renter ID: ");
		// renderLbl.setFont(font1);
		// renderLbl.setBounds(100,800,125,30);
		// panel3.add(renderLbl);
		
		// JTextField renrerID=new JTextField(10);
		// renrerID.setBounds(625,800,210,30);
		// panel3.add(renrerID);
		
		JButton exitButton=new JButton(" Exit ");
		exitButton.setBackground(new Color(0xc9302c));
		exitButton.setForeground(Color.white);
		exitButton.setBounds(625,800,105,30);
		panel3.add(exitButton);
		
		panel3.setBounds(0,500,1800,500);    
		panel3.setBackground(new Color(0xe5e4e4));
		add(panel3);
		/* End Code of Panel 3 */
		
		entryButton.addActionListener(this);
		cancelButton.addActionListener(this);
		exitButton.addActionListener(this);
		
		this.setSize(1000,1000);    
		this.setLayout(null);    
		//this.setVisible(true); 
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	
	
	public void showInfo(){
		JPanel panel2=new JPanel(new BorderLayout());
		String[][] tableData = new String[countDbTableRow("guest_entry")][8];
		String sql2="SELECT *,DATE_FORMAT(entry_time, '%d-%b-%Y %r') as entry,DATE_FORMAT(exit_time, '%d-%b-%Y %r') as exitin FROM guest_entry";
		int counter=0;
		try{
			DataAccess da=new DataAccess();
			ResultSet rs1=da.getData(sql2);
			//String data="";
			while(rs1.next()){
				tableData[counter][0] = rs1.getString("id");
				tableData[counter][1] = rs1.getString("name");
				tableData[counter][2] = rs1.getString("flat_id");
				tableData[counter][3] = rs1.getString("mobile_no");
				tableData[counter][4] = rs1.getString("entry");
				tableData[counter][5] = rs1.getString("exitin");
				tableData[counter][6] = rs1.getString("ref_name");
				tableData[counter][7] = rs1.getString("address");
				//data[counter][6]=rowCount=rs.getString("total");
				counter++;
				
			}
			//System.out.println(rs1)
			//ta.setText(data);
		}
		catch(Exception ex){
			System.out.println("Exception in show info sql 1");
		}

		// String data[][]={ 
							// {"12345","Tanjimul Islam Tanvir","Tozammel Hossain","Khadiza Khatun","Rohanpur, Gomastapur, Chapainawanganj","0123456789","01792426831"}, 
							// {"1","Tanjimul Islam Tanvir","Tozammel Hossain","Khadiza Khatun","Rohanpur, Gomastapur, Chapainawanganj","0123456789","01792426831"},  
							// {"1","Tanjimul Islam Tanvir","Tozammel Hossain","Khadiza Khatun","Rohanpur, Gomastapur, Chapainawanganj","0123456789","01792426831"}  						
						// };  
					  
		String column[]={"ID","Name","Flat","Mobile No","Entry Time","Exit Time","Ref Name","Address",};         
		tableModel = new DefaultTableModel(tableData,column);
		table=new JTable(tableModel);    
			//table.setBounds(0,0,800,900);          
		JScrollPane sp=new JScrollPane(table);	
		sp.setPreferredSize(new Dimension(800, 500));
					//sp.setBounds(500,0,500,900);
					
		table.setRowHeight(25);
		//table.setRowWidth(100);			
		table.getColumnModel().getColumn(0).setPreferredWidth(50);
		table.getColumnModel().getColumn(1).setPreferredWidth(130);
		table.getColumnModel().getColumn(2).setPreferredWidth(75);
		table.getColumnModel().getColumn(3).setPreferredWidth(100);
		table.getColumnModel().getColumn(4).setPreferredWidth(170);
		table.getColumnModel().getColumn(5).setPreferredWidth(170);
		table.getColumnModel().getColumn(6).setPreferredWidth(100);
		table.getColumnModel().getColumn(7).setPreferredWidth(180);
		//table.setEditable(false);
		panel2.setBounds(500,0,860,500);    
		panel2.setBackground(Color.green);
		panel2.add(sp);
		this.add(panel2);
	}

	public void actionPerformed(ActionEvent e){
		//System.out.println(e.getActionCommand());
		String sig=e.getActionCommand();
		
		if(sig.equals("  Entry  ")){
			if(isEmpty(name) || isEmpty(phoneNo) || isEmpty(flatId)|| isEmpty(entryTime)|| isEmpty(address)){
				JOptionPane.showMessageDialog(this,"Please Fillup mandatory fields");
			}
			else if(!isValidAddress(address)){
				JOptionPane.showMessageDialog(this,"Address must have Village,Thana,Zilla");
			}
			else if(!isValidPhoneNo(phoneNo)){
				JOptionPane.showMessageDialog(this,"Phone Number Invalid");
			}
			else{
				DataAccess da=new DataAccess();
				int id;
				String sql="insert into guest_entry(name,mobile_no,address,flat_id,entry_time,ref_name) values('"+toFirstCapital(name.getText())+"','"+toFirstCapital(phoneNo.getText())+"','"+toFirstCapital(address.getText())+"','"+flatId.getText()+"','"+entryTime.getText()+"','"+toFirstCapital(refName.getText())+"')";
				
				if(da.updateDB(sql)>0){
					tableModel.addRow(new Object[]{da.getLastId(), toFirstCapital(name.getText()),flatId.getText(),phoneNo.getText(),entryTime.getText(),"", toFirstCapital(refName.getText()), toFirstCapital(address.getText())});
					JOptionPane.showMessageDialog(this,""+toFirstCapital(name.getText())+" now permited to enter. Ref ID: "+da.getLastId()+"");
				}else{
					JOptionPane.showMessageDialog(this,"Something Went Wrong");
				}
				System.out.println(sql);
				// String smsBody = "Congratulation!\nDear "+name.getText()+" You are now registered on Flat Rent Managment System.";
				// SMSSender sms = new SMSSender();
				// sms.sendSMS(phoneNo.getText(),smsBody);
			}
		}
		else if(sig.equals(" Exit ")){
			int row = table.getSelectedRow();
			String userNo = tableModel.getValueAt(row,0).toString();
			String rName = tableModel.getValueAt(row,1).toString();
			//tableModel.removeRow(table.getSelectedRow());	
			//if(){
				DataAccess daa=new DataAccess();
				String sql="update `guest_entry` set exit_time='"+getNowTime()+"' WHERE exit_time='0000-00-00 00:00:00' and `id` = "+userNo+"";			
				if(daa.updateDB(sql)>0){
					JOptionPane.showMessageDialog(this,"Guest "+rName+" is now Exited Successfully");
				}
				else{
					JOptionPane.showMessageDialog(this,"Guest "+rName+" Already Exited");
				}
				System.out.println(sql);
			//}
		}				
		else if(sig.equals("  Cancel  ")){
			System.exit(0);
		}
	}
	
	

}