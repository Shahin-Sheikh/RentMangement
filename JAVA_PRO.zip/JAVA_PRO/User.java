import java.awt.Color;
import java.awt.Font;
import java.awt.*;
import java.awt.font.*;
import java.io.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

import java.time.LocalDateTime; 
import java.time.format.DateTimeFormatter; 
import javax.swing.table.DefaultTableModel;


public class User extends JFrame{
	 protected JTextField name,phoneNo;
	 protected JLabel lName,lPhone,msg;
	 protected JButton addButton,cancelButton;
	static String userName;
	static int userID;
	//protected String title;
	protected Font font1 = new Font("SansSerif", Font.BOLD, 15);
	
	protected DefaultTableModel tableModel;
	protected JTable table;

	// public User(String s){
		// super(s);
	// }	
	
	public User(){
		//super(title);
		// lName=new JLabel("Name: ");
		// name=new JTextField(10);
		// lPhone=new JLabel("Phone no: ");
		// phoneNo=new JTextField(10);
		// msg=new JLabel("  ");
	}
	
	public int countDbTableRow(String tableName){
		String sql="SELECT count(*) as total FROM "+tableName+"";
		int rowCount=0;
		try{
			DataAccess da=new DataAccess();
			ResultSet rs=da.getData(sql);
			//String data="";
			while(rs.next()){
				 rowCount=rs.getInt("total");
			}
			//ta.setText(data);
			//System.out.println(rowCount);
		}
		catch(Exception ex){
			System.out.println("DB Table Data Counting Error!");
		}
		return rowCount;
	}
	
	public boolean isEmpty(JTextField s){		
		String data = s.getText();
		return data.isEmpty();	
	}
	
	public boolean isNumeric(String str) {
		return str != null && str.matches("[-+]?\\d*\\.?\\d+");
	}
	
	
	public boolean isValidNid(JTextField s){
		
		String data = s.getText();	
		if((data.length()==10 || data.length()==13 || data.length()==17) && isNumeric(data))
		{
			return true;
		}
		else{
			return false;
		}
	}

	public boolean isValidPhoneNo(JTextField s){
		
		String data = s.getText();		
		if(data.length()==11 && data.charAt(0)=='0' && data.charAt(1)=='1' && isNumeric(data))
		{
			return true;
		}
		else{
			return false;
		}
	}	
	
	public boolean isValidAddress(JTextField e){
		String someString = e.getText();;
		char someChar = ',';
		int count = 0;  
		for (int i = 0; i < someString.length(); i++) {
			if (someString.charAt(i) == someChar) {
				count++;
			}
		}
		
		if(count>=2)
		{
			return true;
		}
		else{
			return false;
		}
	}
	
	public String getNowTime(){
		LocalDateTime curTime = LocalDateTime.now();
		DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String formattedDate = curTime.format(dateFormat);
		return formattedDate;
	}
	
	public String toFirstCapital(String text) { 
		text = text.toLowerCase(); 
        StringBuffer sentence = new StringBuffer(); 
        char ch = ' '; 
        for (int i = 0; i < text.length(); i++) {            
            if (ch == ' ' && text.charAt(i) != ' ') 
                sentence.append(Character.toUpperCase(text.charAt(i))); 
            else
                sentence.append(text.charAt(i)); 
            ch = text.charAt(i); 
        } 
        return sentence.toString().trim(); 
    } 

}