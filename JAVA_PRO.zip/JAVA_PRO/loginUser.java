import java.awt.*;
import java.awt.font.*;
import java.io.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.table.DefaultTableModel;

public class loginUser extends User implements ActionListener,ItemListener{
	private JTextField email,nidNo,photo;
	private JPasswordField password;
	private JComboBox role_id;
	private JLabel l,l2,l3,l4,l5,l6,l7;
	private int roleID;
	private String roleName;
	public loginUser(){
		super.setTitle("loginUser Management");
		/* Start Code of Panel 1 */    
		JPanel panel=new JPanel(new BorderLayout());

		lName=new JLabel("Name: ");
		lName.setFont(font1);
		lName.setBounds(20,60,125,30);
		panel.add(lName);
				
		name=new JTextField(10);
		name.setBounds(125,60,210,30);
		panel.add(name);
			
		l2=new JLabel("E-mail: ");
		l2.setFont(font1);
		l2.setBounds(20,95,125,30);
		panel.add(l2);
				
		email=new JTextField(10);
		email.setBounds(125,95,210,30);
		panel.add(email);
		
		l3=new JLabel("Password: ");
		l3.setFont(font1);
		l3.setBounds(20,130,125,30);
		panel.add(l3);
				
		password=new JPasswordField(10);
		password.setBounds(125,130,210,30);
		//password.setEchoChar('*');
		//password.setEchoChar('\000');
		panel.add(password);
		
		l4=new JLabel("Role : ");
		l4.setFont(font1);
		l4.setBounds(20,165,125,30);
		panel.add(l4);
			
		String roles[]={"None","Admin","FlatOwner","CateTaker"};
		JComboBox<String> role_id = new JComboBox<String>(roles);
		//JComboBox selectBox=new JComboBox(roles);
		//role_id=new JTextField(10);
		role_id.setBounds(125,165,210,30);
		panel.add(role_id);
		
		// l5=new JLabel("NID No: ");
		// l5.setFont(font1);
		// l5.setBounds(20,200,125,30);
		// panel.add(l5);
		
		// nidNo=new JTextField(10);
		// nidNo.setBounds(125,200,210,30);
		// panel.add(nidNo);
		
		lPhone=new JLabel("Phone no: ");
		lPhone.setFont(font1);
		lPhone.setBounds(20,200,125,30);
		panel.add(lPhone);
		
		phoneNo=new JTextField(10);
		phoneNo.setBounds(125,200,210,30);
		panel.add(phoneNo);
			
		addButton=new JButton("  Add  ");
		addButton.setBackground(new Color(0x449d44));
		addButton.setForeground(Color.white);
		addButton.setBounds(125,305,105,30);
		panel.add(addButton);
		
		cancelButton=new JButton("  Update  ");
		cancelButton.setBackground(new Color(0xc9302c));
		cancelButton.setForeground(Color.white);
		cancelButton.setBounds(225,305,105,30);
		panel.add(cancelButton);
		
		msg=new JLabel("  ");
		msg.setBounds(215,340,210,30);
		panel.add(msg);
		
		panel.setBounds(0,0,500,500);    
		panel.setBackground(new Color(0xe5e4e4));
		this.add(panel); 
		
		/* End Code of Panel 2 */
		this.showInfo();
		/* End Code of Panel 2 */

		/* Start Code of Panel 3 */
		JPanel panel3=new JPanel();
		// JLabel renderLbl=new JLabel("Renter ID: ");
		// renderLbl.setFont(font1);
		// renderLbl.setBounds(100,800,125,30);
		// panel3.add(renderLbl);
		
		// JTextField renrerID=new JTextField(10);
		// renrerID.setBounds(625,800,210,30);
		// panel3.add(renrerID);
		
		JButton removeButton=new JButton("  Delete  ");
		removeButton.setBackground(new Color(0xc9302c));
		removeButton.setForeground(Color.white);
		removeButton.setBounds(625,800,105,30);
		panel3.add(removeButton);
		
		panel3.setBounds(0,500,1800,500);    
		panel3.setBackground(new Color(0xe5e4e4));
		add(panel3);
		/* End Code of Panel 3 */
		
		addButton.addActionListener(this);
		cancelButton.addActionListener(this);
		removeButton.addActionListener(this);
		
		role_id.addItemListener(this);
		role_id.addActionListener(this);
		
		this.setSize(1000,1000);    
		this.setLayout(null);    
		//this.setVisible(true); 
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
		
	public void showInfo(){
		JPanel panel2=new JPanel(new BorderLayout());
		String[][] tableData = new String[countDbTableRow("users")][7];
		String sql2="SELECT *,CASE WHEN role_id=1 THEN 'Admin' WHEN role_id=2 THEN 'FlatOwner' WHEN role_id=3 THEN 'CateTaker' ELSE 'None' END as role,CASE WHEN accountStatus=1 THEN 'Active' ELSE 'InActive' END as idstatus FROM `users`";
		int counter=0;
		try{
			DataAccess da=new DataAccess();
			ResultSet rs1=da.getData(sql2);
			//String data="";
			while(rs1.next()){
				tableData[counter][0] = rs1.getString("user_id");
				tableData[counter][1] = rs1.getString("name");
				tableData[counter][2] = rs1.getString("mobile_no");
				tableData[counter][3] = rs1.getString("email");
				tableData[counter][4] = "******";
				tableData[counter][5] = rs1.getString("role");
				tableData[counter][6] = rs1.getString("idstatus");
				//data[counter][6]=rowCount=rs.getString("total");
				counter++;	
			}
			//System.out.println(rs1)
			//ta.setText(data);
		}
		catch(Exception ex){
			System.out.println("Exception in show info sql 1");
		}
					  
		String column[]={"ID","Name","Mobile No","E-mail","Password","Role","Status"};         
		tableModel = new DefaultTableModel(tableData,column);
		table=new JTable(tableModel);    
		//table.setBounds(0,0,800,900);          
		JScrollPane sp=new JScrollPane(table);	
		sp.setPreferredSize(new Dimension(800, 500));
		//sp.setBounds(500,0,500,900);			
		table.setRowHeight(25);
		//table.setRowWidth(100);			
		table.getColumnModel().getColumn(0).setPreferredWidth(50);
		table.getColumnModel().getColumn(1).setPreferredWidth(130);
		table.getColumnModel().getColumn(2).setPreferredWidth(120);
		table.getColumnModel().getColumn(3).setPreferredWidth(200);
		table.getColumnModel().getColumn(4).setPreferredWidth(85);
		table.getColumnModel().getColumn(5).setPreferredWidth(85);
		table.getColumnModel().getColumn(6).setPreferredWidth(85);
		//table.getColumnModel().getColumn(6).setPreferredWidth(100);
		//table.setEditable(false);
		panel2.setBounds(500,0,860,500);    
		panel2.setBackground(Color.green);
		panel2.add(sp);
		this.add(panel2);
	}


    public void itemStateChanged(ItemEvent e) 
    { 
		JComboBox comboBox = (JComboBox) e.getSource();
		Object selected = comboBox.getSelectedItem();		
		String selectVal = String.valueOf(selected);
		this.roleName=selectVal;
		if(selectVal=="Admin")
		{
			this.roleID=1;
		}
		else if(selectVal=="FlatOwner")
		{
			this.roleID=2;
		}
		else if(selectVal=="CateTaker")
		{
			this.roleID=3;
		}
		else{
			this.roleID=0;
		}	
    } 


	public void actionPerformed(ActionEvent e){
		//System.out.println(e.getActionCommand());
		String sig=e.getActionCommand();
		
		if(sig.equals("  Add  ")){
			if(isEmpty(name) || isEmpty(email) || isEmpty(password)|| isEmpty(phoneNo)){
				JOptionPane.showMessageDialog(this,"All fields are mandatory");
			}
			else if(!isValidPhoneNo(phoneNo)){
				JOptionPane.showMessageDialog(this,"Phone Number Invalid");
			}
			else{	
				DataAccess da=new DataAccess();
				String sql = "insert into users(name,email,password,role_id,accountStatus,mobile_no,photo,reg_time) values('"+toFirstCapital(name.getText())+"','"+email.getText()+"','"+password.getText()+"','"+roleID+"','1','"+phoneNo.getText()+"','-','"+getNowTime()+"')";				
				if(da.updateDB(sql)>0){
					JOptionPane.showMessageDialog(this,"Successfull. Ref ID: "+da.getLastId()+"");
					tableModel.addRow(new Object[]{da.getLastId(), toFirstCapital(name.getText()),phoneNo.getText(), email.getText(), "******",roleName,"Active"});
					
					// String smsBody = "Congratulation!\nDear "+toFirstCapital(name.getText())+" You are now registered on Flat Rent Managment System.";
					// SMSSender sms = new SMSSender();
					// sms.sendSMS(phoneNo.getText(),smsBody);					
				}
				else{
					JOptionPane.showMessageDialog(this,"Something wrong");
				}
				System.out.println(sql);
			}
		}
		else if(sig.equals("  Update  ")){
			if(isEmpty(name) || isEmpty(email) || isEmpty(password)|| isEmpty(phoneNo)){
				JOptionPane.showMessageDialog(this,"All fields are mandatory");
			}
			else if(!isValidPhoneNo(phoneNo)){
				JOptionPane.showMessageDialog(this,"Phone Number Invalid");
			}
			else{			
				DataAccess da=new DataAccess();
				String sql="update users set name='"+toFirstCapital(name.getText())+"',email='"+email.getText()+"',password='"+password.getText()+"',role_id='"+roleID+"',mobile_no='"+phoneNo.getText()+"',photo='' where mobile_no='"+phoneNo.getText()+"'";
				
				if(da.updateDB(sql)>0){
					JOptionPane.showMessageDialog(this,"Update Successfull. But Now Not effected on User Table.");
				}
				else{
					JOptionPane.showMessageDialog(this,"No User Found On Mobile No: "+phoneNo.getText());
				}
				System.out.println(sql);
				// String smsBody = "Congratulation!\nDear "+name.getText()+" You are now registered on Flat Rent Managment System.";
				// SMSSender sms = new SMSSender();
				// sms.sendSMS(phoneNo.getText(),smsBody);
			}
		}
		else if(sig.equals("  Delete  ")){
			int row = table.getSelectedRow();
			String userNo = tableModel.getValueAt(row,0).toString();
			String rName = tableModel.getValueAt(row,1).toString();
			//tableModel.removeRow(table.getSelectedRow());	
			//if(){
				DataAccess daa=new DataAccess();
				String sql="DELETE FROM `users` WHERE `user_id` = "+userNo+"";			
				if(daa.updateDB(sql)>0){
					tableModel.removeRow(table.getSelectedRow());	
					JOptionPane.showMessageDialog(this,"User "+rName+" is Successfully Deleted");
				}
				else{
					JOptionPane.showMessageDialog(this,"No User Found ");
				}
				System.out.println(sql);
			//}
		}		
		else if(sig.equals("Cancel")){
			System.exit(0);
		}
	}
}