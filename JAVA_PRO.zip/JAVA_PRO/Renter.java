import java.awt.*;
import java.awt.font.*;
import java.io.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.table.DefaultTableModel;

public class Renter extends User implements ActionListener{
	private JTextField fatherName,motherName,address,nidNo,photo;
	private JLabel l,l2,l3,l4,l5,l6,l7;
	public Renter(){
		super.setTitle("Renter Management");
		/* Start Code of Panel 1 */    
		JPanel panel=new JPanel(new BorderLayout());

		lName=new JLabel("Name: ");
		lName.setFont(font1);
		lName.setBounds(20,60,125,30);
		panel.add(lName);
				
		name=new JTextField(10);
		name.setBounds(125,60,210,30);
		panel.add(name);
			
		l2=new JLabel("Father Name: ");
		l2.setFont(font1);
		l2.setBounds(20,95,125,30);
		panel.add(l2);
				
		fatherName=new JTextField(10);
		fatherName.setBounds(125,95,210,30);
		panel.add(fatherName);
		
		l3=new JLabel("Mother Name: ");
		l3.setFont(font1);
		l3.setBounds(20,130,125,30);
		panel.add(l3);
				
		motherName=new JTextField(10);
		motherName.setBounds(125,130,210,30);
		panel.add(motherName);
		
		l4=new JLabel("Address : ");
		l4.setFont(font1);
		l4.setBounds(20,165,125,30);
		panel.add(l4);
		
		address=new JTextField(10);
		address.setBounds(125,165,210,30);
		panel.add(address);
		
		l5=new JLabel("NID No: ");
		l5.setFont(font1);
		l5.setBounds(20,200,125,30);
		panel.add(l5);
		
		nidNo=new JTextField(10);
		nidNo.setBounds(125,200,210,30);
		panel.add(nidNo);
		
		lPhone=new JLabel("Phone no: ");
		lPhone.setFont(font1);
		lPhone.setBounds(20,235,125,30);
		panel.add(lPhone);
		
		phoneNo=new JTextField(10);
		phoneNo.setBounds(125,235,210,30);
		panel.add(phoneNo);
		
		l7=new JLabel("Photo: ");
		l7.setFont(font1);
		l7.setBounds(20,270,125,30);
		panel.add(l7);
		
		photo=new JTextField(10);
		photo.setBounds(125,270,210,30);
		panel.add(photo);

		addButton=new JButton("  Add  ");
		addButton.setBackground(new Color(0x449d44));
		addButton.setForeground(Color.white);
		addButton.setBounds(125,305,105,30);
		panel.add(addButton);
		
		cancelButton=new JButton("  Update  ");
		cancelButton.setBackground(new Color(0xc9302c));
		cancelButton.setForeground(Color.white);
		cancelButton.setBounds(225,305,105,30);
		panel.add(cancelButton);
		
		msg=new JLabel("  ");
		msg.setBounds(215,340,210,30);
		panel.add(msg);
		
		panel.setBounds(0,0,500,500);    
		panel.setBackground(new Color(0xe5e4e4));
		this.add(panel); 
		
		/* End Code of Panel 2 */
		this.showInfo();
		/* End Code of Panel 2 */

		/* Start Code of Panel 3 */
		JPanel panel3=new JPanel();
		// JLabel renderLbl=new JLabel("Renter ID: ");
		// renderLbl.setFont(font1);
		// renderLbl.setBounds(100,800,125,30);
		// panel3.add(renderLbl);
		
		// JTextField renrerID=new JTextField(10);
		// renrerID.setBounds(625,800,210,30);
		// panel3.add(renrerID);
		
		JButton removeButton=new JButton("  Delete  ");
		removeButton.setBackground(new Color(0xc9302c));
		removeButton.setForeground(Color.white);
		removeButton.setBounds(625,800,105,30);
		panel3.add(removeButton);
		
		panel3.setBounds(0,500,1800,500);    
		panel3.setBackground(new Color(0xe5e4e4));
		add(panel3);
		/* End Code of Panel 3 */
		
		addButton.addActionListener(this);
		cancelButton.addActionListener(this);
		removeButton.addActionListener(this);
		
		this.setSize(1000,1000);    
		this.setLayout(null);    
		//this.setVisible(true); 
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	
	
public void showInfo(){
	JPanel panel2=new JPanel(new BorderLayout());
	String[][] tableData = new String[countDbTableRow("renter_info")][7];
	String sql2="SELECT * FROM `renter_info`";
	int counter=0;
	try{
		DataAccess da=new DataAccess();
		ResultSet rs1=da.getData(sql2);
		//String data="";
		while(rs1.next()){
			tableData[counter][0] = rs1.getString("renter_id");
			tableData[counter][1] = rs1.getString("name");
			tableData[counter][2] = rs1.getString("father_name");
			tableData[counter][3] = rs1.getString("mother_name");
			tableData[counter][4] = rs1.getString("nid_no");
			tableData[counter][5] = rs1.getString("mobile_no");
			tableData[counter][6] = rs1.getString("address");
			//data[counter][6]=rowCount=rs.getString("total");
			counter++;
			
		}
		//System.out.println(rs1)
		//ta.setText(data);
	}
	catch(Exception ex){
		System.out.println("Exception in show info sql 1");
	}

	// String data[][]={ 
						// {"12345","Tanjimul Islam Tanvir","Tozammel Hossain","Khadiza Khatun","Rohanpur, Gomastapur, Chapainawanganj","0123456789","01792426831"}, 
						// {"1","Tanjimul Islam Tanvir","Tozammel Hossain","Khadiza Khatun","Rohanpur, Gomastapur, Chapainawanganj","0123456789","01792426831"},  
						// {"1","Tanjimul Islam Tanvir","Tozammel Hossain","Khadiza Khatun","Rohanpur, Gomastapur, Chapainawanganj","0123456789","01792426831"}  						
					// };  
				  
	String column[]={"ID","Name","Father Name","Mother name","Nid No","Mobile No","Address"};         
	tableModel = new DefaultTableModel(tableData,column);
	table=new JTable(tableModel);    
		//table.setBounds(0,0,800,900);          
	JScrollPane sp=new JScrollPane(table);	
	sp.setPreferredSize(new Dimension(800, 500));
				//sp.setBounds(500,0,500,900);
				
	table.setRowHeight(25);
	//table.setRowWidth(100);			
	table.getColumnModel().getColumn(0).setPreferredWidth(50);
	table.getColumnModel().getColumn(1).setPreferredWidth(130);
	table.getColumnModel().getColumn(2).setPreferredWidth(120);
	table.getColumnModel().getColumn(3).setPreferredWidth(100);
	table.getColumnModel().getColumn(4).setPreferredWidth(110);
	table.getColumnModel().getColumn(5).setPreferredWidth(85);
	table.getColumnModel().getColumn(6).setPreferredWidth(210);
	//table.getColumnModel().getColumn(6).setPreferredWidth(100);
	//table.setEditable(false);
	panel2.setBounds(500,0,860,500);    
	panel2.setBackground(Color.green);
	panel2.add(sp);
	this.add(panel2);
}
	public void actionPerformed(ActionEvent e){
		//System.out.println(e.getActionCommand());
		String sig=e.getActionCommand();
		
		if(sig.equals("  Add  ")){
			if(isEmpty(name) || isEmpty(fatherName) || isEmpty(motherName)|| isEmpty(address)|| isEmpty(nidNo)|| isEmpty(phoneNo)){
				JOptionPane.showMessageDialog(this,"All fields are mandatory");
			}
			else if(!isValidAddress(address)){
				JOptionPane.showMessageDialog(this,"Address must have Village,Thana,Zilla");
			}
			else if(!isValidNid(nidNo)){
				JOptionPane.showMessageDialog(this,"NID No Must be 10 or 13 or 17 digits");
			}
			else if(!isValidPhoneNo(phoneNo)){
				JOptionPane.showMessageDialog(this,"Phone Number Invalid");
			}
			else{
				DataAccess da=new DataAccess();
				String sql="insert into renter_info(name,father_name,mother_name,address,nid_no,mobile_no,photo) values('"+toFirstCapital(name.getText())+"','"+toFirstCapital(fatherName.getText())+"','"+toFirstCapital(motherName.getText())+"','"+toFirstCapital(address.getText())+"','"+nidNo.getText()+"','"+phoneNo.getText()+"','"+photo.getText()+"')";
				
				
				if(da.updateDB(sql)>0){
					//this.showInfo();
					JOptionPane.showMessageDialog(this,"Successfull. Ref ID: "+da.getLastId());
					tableModel.addRow(new Object[]{da.getLastId(), toFirstCapital(name.getText()), toFirstCapital(fatherName.getText()), toFirstCapital(motherName.getText()), nidNo.getText(),phoneNo.getText(),toFirstCapital(address.getText())});
					// String smsBody = "Congratulation!\nDear "+toFirstCapital(name.getText())+" You are now registered on Flat Rent Managment System.";
					// SMSSender sms = new SMSSender();
					// sms.sendSMS(phoneNo.getText(),smsBody);	
				}
				else{
					JOptionPane.showMessageDialog(this,"Something wrong");
				}
				System.out.println(sql);
				
			}
		}
		else if(sig.equals("  Update  ")){
			if(isEmpty(name) || isEmpty(fatherName) || isEmpty(motherName)|| isEmpty(address)|| isEmpty(nidNo)|| isEmpty(phoneNo)){
				JOptionPane.showMessageDialog(this,"All fields are mandatory");
			}
			else if(!isValidAddress(address)){
				JOptionPane.showMessageDialog(this,"Address must have Village,Thana,Zilla");
			}
			else if(!isValidNid(nidNo)){
				JOptionPane.showMessageDialog(this,"NID No Must be 10 or 13 or 17 digits");
			}
			else if(!isValidPhoneNo(phoneNo)){
				JOptionPane.showMessageDialog(this,"Phone Number Invalid");
			}
			else{
				DataAccess da=new DataAccess();
				String sql="update renter_info set name='"+toFirstCapital(name.getText())+"',father_name='"+toFirstCapital(fatherName.getText())+"',mother_name='"+toFirstCapital(motherName.getText())+"',address='"+toFirstCapital(address.getText())+"',nid_no='"+nidNo.getText()+"',mobile_no='"+phoneNo.getText()+"',photo='"+photo.getText()+"' where mobile_no='"+phoneNo.getText()+"'";
				
				if(da.updateDB(sql)>0){
					JOptionPane.showMessageDialog(this,"Update Successfull. But Now Not effected on Renter Table.");
				}
				else{
					JOptionPane.showMessageDialog(this,"No Renter Found On Mobile No: "+phoneNo.getText());
				}
				System.out.println(sql);
				// String smsBody = "Congratulation!\nDear "+name.getText()+" You are now registered on Flat Rent Managment System.";
				// SMSSender sms = new SMSSender();
				// sms.sendSMS(phoneNo.getText(),smsBody);
			}
		}
		else if(sig.equals("  Delete  ")){
			int row = table.getSelectedRow();
			String renterNo = tableModel.getValueAt(row,0).toString();
			String rName = tableModel.getValueAt(row,1).toString();
			
			//if(){
				DataAccess daa=new DataAccess();
				String sql="DELETE FROM `renter_info` WHERE `renter_id` = "+renterNo+"";			
				if(daa.updateDB(sql)>0){
					tableModel.removeRow(table.getSelectedRow());	
					JOptionPane.showMessageDialog(this,"Renter "+rName+" is Successfully Deleted");
				}
				else{
					JOptionPane.showMessageDialog(this,"No Renter Found ");
				}
				System.out.println(sql);
			//}
		}		
		else if(sig.equals("Cancel")){
			System.exit(0);
		}
	}
}