import java.awt.Color;
import java.awt.Font;
import java.awt.*;
import java.awt.font.*;
import java.io.*;
import javax.swing.*;
import java.awt.event.*;

public class Navigate extends JFrame implements ActionListener{
	private JButton signupButton,loginButton,renterButton,guestButton,userDetails;
	public static Login log;
	public static Signup sup;
	public static Home home;
	public static User addRenter;
	public static User guest;
	public static User loginUserDetails;
	public Navigate(){
		super("Navigation Window");
		log=new Login();
		sup=new Signup();
		home=new Home();
		guest = new Guest();
		addRenter=new Renter();
		loginUserDetails = new loginUser();
		
		
		loginButton=new JButton("Login");
		signupButton=new JButton("Signup");
		renterButton=new JButton("Renter");
		guestButton = new JButton("Guest Entry");
		userDetails = new JButton("User Details");
		
		add(loginButton);add(signupButton);
		add(renterButton);
		add(guestButton);
		add(userDetails);
		
		signupButton.addActionListener(this);
		loginButton.addActionListener(this);
		renterButton.addActionListener(this);
		guestButton.addActionListener(this);
		userDetails.addActionListener(this);
		setLayout(new FlowLayout());
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocation(500,100);
		setSize(400,500);
	}
	public void actionPerformed(ActionEvent e){
		//System.out.println(e.getActionCommand());
		String sig=e.getActionCommand();
		if(sig.equals("Signup")){
			this.setVisible(false);
			sup.setVisible(true);
		}
		else if(sig.equals("Login")){
			this.setVisible(false);
			log.setVisible(true);
			log.setParent(this);
		}
		else if(sig.equals("Renter")){
			this.setVisible(false);
			addRenter.setVisible(true);
			//addRenter.setParent(this);
		}
		else if(sig.equals("Guest Entry")){
			this.setVisible(false);
			guest.setVisible(true);
			//addRenter.setParent(this);
		}
		
		else if(sig.equals("User Details")){
			this.setVisible(false);
			loginUserDetails.setVisible(true);
			//addRenter.setParent(this);
		}
		else if(sig.equals("Cancel")){
			System.exit(0);
		}
	}
}