import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

public class SMSSender {
	
	// private String phoneNumber;
	// private String message;
	
	
	public SMSSender(){
		
	}
	
	public void sendSMS(String phone,String message){
		
		// String message = "Junk cu want to sexcerpt from android cts. It has example on how to send long messages.";		
		// String phone = "01792426831";
		
		
		String username = "tnrAdmin";
		String password = "AccBddTNR91";
		String address = "https://api.tnrsoft.com";
		String port = "";
		
		try {
			URL url = new URL(
					address+":"+port+"/SendSMS.php?username="+username+"&password="+password+
					"&phone="+phone+"&message="+URLEncoder.encode(message,"UTF-8"));
			
			URLConnection connection = url.openConnection();
			BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			String inputLine;
			while((inputLine = bufferedReader.readLine()) !=null){
				System.out.println(inputLine);
			}
			bufferedReader.close();
		
		}
		catch(Exception e) {
				System.out.println("SMS Server Connection failed");
		}
	}

	// public static void main(String[] args){
		// SMSSender a = new SMSSender();
		// a.sendSMS("01792426831","Success java");

		

	// }

}