import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class Home extends Frame implements ActionListener, WindowListener{
	private TextField tf,pf;
	private Button logoutButton,exitButton;
	private TextArea ta;
	private Frame parent;
	public Home(){
		super("Java Login Window");
		logoutButton=new Button("Logout");
		exitButton=new Button("Exit");
		ta=new TextArea(10,50);
		ta.setEditable(false);
		add(ta);
		add(logoutButton);add(exitButton);
		logoutButton.addActionListener(this);
		exitButton.addActionListener(this);
		addWindowListener(this);
		setLayout(new FlowLayout());
		setSize(400,300);
	}
	public void loadData(){
		String sql="select * from user";
		try{
			DataAccess da=new DataAccess();
			ResultSet rs=da.getData(sql);
			String data="";
			while(rs.next()){
				data=data+rs.getString("uname")+"-";
				data=data+rs.getString("email")+"\n";
			}
			ta.setText(data);
		}
		catch(Exception ex){
			System.out.println("Exception in home");
		}
	}
	public void setParent(Frame f){
		parent=f;
	}
	public void actionPerformed(ActionEvent e){
		if(e.getSource()==logoutButton){
			this.setVisible(false);
			parent.setVisible(true);
		}
		else if(e.getSource()==exitButton){
			System.exit(0);
		}
	}
	public void windowActivated(WindowEvent e){	}
	public void windowClosed(WindowEvent e){}
	public void windowClosing(WindowEvent e){
		this.setVisible(false);
		parent.setVisible(true);
	}
	public void windowDeactivated(WindowEvent e){}
	public void windowDeiconified(WindowEvent e){}
	public void windowIconified(WindowEvent e){}
	public void windowOpened(WindowEvent e){}
}