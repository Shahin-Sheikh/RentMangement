import java.awt.*;
import java.awt.font.*;
import java.io.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.table.DefaultTableModel;


public class Login extends JFrame implements ActionListener{
	
	private JTextField userName;
	private JPasswordField password;
	private JButton cancelButton,loginButton;
	private JLabel l,l2,msg;
	private JFrame parent;
	private int userRole;
	static String loggedUserName;
	static int loggedUserId;
	
	public Login(){
		super("User Login");
		
		JPanel panel=new JPanel(new BorderLayout());
		Font font1 = new Font("Roboto", Font.BOLD, 15);

		l=new JLabel("Email");
		l.setFont(font1);
		l.setBounds(20,60,125,30);
		add(l);
				
		userName=new JTextField(10);
		userName.setBounds(125,60,210,30);
		add(userName);
			
		l2=new JLabel("Password ");
		l2.setFont(font1);
		l2.setBounds(20,95,125,30);
		add(l2);
				
		password=new JPasswordField(10);
		password.setBounds(125,95,210,30);
		add(password);
		
		loginButton=new JButton("  Login  ");
		loginButton.setBackground(new Color(0x0069d9));
		loginButton.setForeground(Color.white);
		loginButton.setBounds(125,130,105,30);
		add(loginButton);
		
		cancelButton=new JButton("  Cancel  ");
		cancelButton.setBackground(new Color(0x5a6268));
		cancelButton.setForeground(Color.white);
		cancelButton.setBounds(225,130,105,30);
		add(cancelButton);
		
		msg=new JLabel("  ");
		msg.setBounds(215,160,210,30);
		add(msg);
	
		//add(panel);
		loginButton.addActionListener(this);
		cancelButton.addActionListener(this);
		setLayout(null);
		setLocation(300,300);
		setSize(460,280);
	}
	public void setParent(JFrame f){
		parent=f;
	}
	private boolean checkAuth(){
		boolean userAuthorized=false;
		String em=userName.getText();
		String pass=password.getText();
		String sql="select * from users where email='"+em+"' and password='"+pass+"'";
		System.out.println(sql);
		try{
			DataAccess da=new DataAccess();
			ResultSet rs=da.getData(sql);
			while(rs.next()){
				this.loggedUserName = rs.getString("name");
				this.loggedUserId = rs.getInt("user_id");
				this.userRole = rs.getInt("role_id");
				userAuthorized=true;
			}
		}
		catch(Exception ex){
			System.out.println("Error in login");
		}
		return userAuthorized;
	}
	
	public boolean isEmpty(JTextField s){		
		String data = s.getText();
		return data.isEmpty();	
	}
	
	public void actionPerformed(ActionEvent e){
		//System.out.println(e.getActionCommand());
		String sig=e.getActionCommand();
		if(sig.equals("  Login  ")){
			if(isEmpty(userName) || isEmpty(password)){
				JOptionPane.showMessageDialog(this,"Password Or Email Can't be Blank");
			}
			else if(checkAuth()){
				
				
				if(loggedUserId==1)
				{
					// System.out.println("Success");
				this.setVisible(false);
				Navigate.addRenter.setVisible(true);
				// Navigate.home.setParent(this);
				// Navigate.home.loadData();
				this.setVisible(false);
				}
				else{
					this.setVisible(false);
					Navigate.guest.setVisible(true);
					// Navigate.home.setParent(this);
					// Navigate.home.loadData();
					this.setVisible(false);
				}
					
					
				
				
				
				
				
				JOptionPane.showMessageDialog(this,"Success"+loggedUserId+loggedUserName+userRole);
			}
			else{
				JOptionPane.showMessageDialog(this,"Login Information Incorrect!");
			}
		}
		else if(sig.equals("  Cancel  ")){
			System.exit(0);
		}
	}
	
	
	// public static void main(String a[]){
		// Login n=new Login();
		// n.setVisible(true);
	// }
	
}